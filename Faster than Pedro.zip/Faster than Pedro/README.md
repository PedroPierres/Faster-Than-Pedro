# MOVEMENT-2

This character controller demo was created with the intent of being a decent starting point for Precision Platformers using Godot.
Instead of teaching the basics, I tried to implement more advanced considerations.

That's why I call it 'Movement 2'. This is a sequel to learning demos of similar a kind.

After playing around with the demo, you could potentially just copy over the Player.gd script and form it to your needs.



## This project is also on itch.io: https://theothetorch.itch.io/movement-2

### Credits

  WhiteShampoo [ Help in understanding and code snippets ]
  
  Totally [ Creator of the icon ]
  
  Dawnosaur [ Making the video that inspired this project ]

![image](https://user-images.githubusercontent.com/57500649/214278821-08a82f76-3cd0-472a-9467-da3c714adc25.png)
![image](https://user-images.githubusercontent.com/57500649/214085074-a8cf40a4-cd1c-49a4-a0a3-9be9fd9049f5.png)
![image](https://user-images.githubusercontent.com/57500649/214085208-de7986bc-8d49-4a07-9976-7630a11a6c15.png)

